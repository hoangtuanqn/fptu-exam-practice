// Cấu hình dùng chung cho content script, background và popup.
// Giá trị mặc định trỏ tới hệ thống thật; chỉ đổi khi chạy thử trên máy (xem popup > Nâng cao).
const FEPASS_DEFAULTS = {
  enabled: true,
  siteUrl: "https://fepass.top",
  apiUrl: "https://api.fepass.top",
};

// So sánh phiên bản dạng 1.2.3: trả true nếu a mới hơn b
function fepassIsNewer(a, b) {
  const pa = String(a).split(".").map((n) => parseInt(n, 10) || 0);
  const pb = String(b).split(".").map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0);
  }
  return false;
}

// Trạng thái "in" cũ hơn mức này coi như chưa chắc (phiên đăng nhập của website sống tối đa 30 ngày không dùng)
const FEPASS_AUTH_TTL_MS = 30 * 24 * 60 * 60 * 1000;

// Chỉ nhận địa chỉ https, hoặc http://localhost khi chạy thử; bỏ dấu / ở cuối. Sai thì trả về giá trị mặc định.
function fepassSanitizeUrl(value, fallback) {
  try {
    const u = new URL(String(value || "").trim());
    const local = u.hostname === "localhost" || u.hostname === "127.0.0.1";
    if (u.protocol !== "https:" && !(u.protocol === "http:" && local)) return fallback;
    return u.origin;
  } catch {
    return fallback;
  }
}

async function fepassGetSettings() {
  const raw = await chrome.storage.sync.get(FEPASS_DEFAULTS);
  return {
    enabled: raw.enabled !== false,
    siteUrl: fepassSanitizeUrl(raw.siteUrl, FEPASS_DEFAULTS.siteUrl),
    apiUrl: fepassSanitizeUrl(raw.apiUrl, FEPASS_DEFAULTS.apiUrl),
  };
}

// Trạng thái đăng nhập fepass.top do content script chạy trên chính website ghi lại (chỉ "in"/"out" và tên hiển thị, không có token).
// Trả về { loggedIn, name }. Chưa từng ghi nhận, khác địa chỉ website đang cấu hình, hoặc quá cũ thì coi là chưa đăng nhập.
async function fepassGetAuth(siteUrl) {
  const { fepassAuth } = await chrome.storage.local.get("fepassAuth");
  const ok = fepassAuth && fepassAuth.origin === siteUrl && Date.now() - fepassAuth.at < FEPASS_AUTH_TTL_MS;
  return { loggedIn: !!ok && fepassAuth.state === "in", name: ok ? fepassAuth.name || "" : "" };
}

// ---- Dùng chung cho popup, trang FAP và nền (từ bản 1.5.0)
const FEPASS_SNOOZE_MS = 24 * 60 * 60 * 1000; // ẩn thông báo trên FAP: 24 giờ
const FEPASS_STALE_MS = 14 * 24 * 60 * 60 * 1000; // điểm đã đọc cũ hơn mức này thì nhắc đồng bộ lại
const FEPASS_GRADE_URL = "https://fap.fpt.edu.vn/Report/Grade";

// 10:32 10/11
function fepassFormatTime(ts) {
  const d = new Date(ts);
  const p = (n) => String(n).padStart(2, "0");
  return `${p(d.getHours())}:${p(d.getMinutes())} ${p(d.getDate())}/${p(d.getMonth() + 1)}`;
}
